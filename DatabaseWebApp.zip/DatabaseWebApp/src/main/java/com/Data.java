package com;

public class Data {
	
	public static String[] title = new String[101];
	public static String[] Duration = new String[100];
	public static String[] Date = new String[100];
	public static String[] lastName = new String[101];
	public static String[] firstName = new String[101];
	public static String[] htmlPrint = new String[101];	

}
