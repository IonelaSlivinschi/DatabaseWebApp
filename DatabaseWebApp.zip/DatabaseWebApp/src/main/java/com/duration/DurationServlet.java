package com.duration;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Data;

@WebServlet("/DurationServlet")
public class DurationServlet extends HttpServlet {

    private static final String sql = "SELECT  duration, title FROM hfri.project";
	public static final long serialVersionUID = 1L;
	int i = 0;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DurationServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		 
		PrintWriter pw = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean flag = false;
		
		response.setContentType("text/html");
	    pw = response.getWriter();
	    
	    pw.println("<html><head><title>Duration</title></head><body>");
	    pw.println("<h2><a href='index.html'>Home</a></h2>");
	    pw.println("<h1>Duration - Title </h1>");
	    try {
	    	 Class.forName("com.mysql.cj.jdbc.Driver");  	
	    	 
	         con = DriverManager.getConnection("jdbc:mysql:///hfri", "db_user", "Student-pass");
	         if (con != null)
	            ps = con.prepareStatement(sql);
	         if (ps != null)
	            rs = ps.executeQuery();
	         if (rs != null) {
	        	 while (rs.next()) {
		             flag = true;
		             Data.title[i] = rs.getString("title");
		             Data.Duration[i++] = rs.getString("Duration");
	        	 }
	         }
	         if (!flag) {
	             pw.println("<h1>Data Not Found.</h1>");
	          }
	    	} catch (SQLException se) {
	         se.printStackTrace();
	         pw.println("Error Occured");
	      } catch (Exception e) {
	         e.printStackTrace();
	         pw.println("Unknown Exception Occured");
	      } finally {
	         try {
	            if (rs != null)
	               rs.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         try {
	            if (ps != null)
	               ps.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         try {
	            if (con != null)
	               con.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         int aux = i;
	         
	         // researcher get Last First Name
	         
	         for(i = 0; i < aux; i++ ) {
	        	 Data.htmlPrint[i] = " ";
		     	con = null;
		     	ps = null;
		     	rs = null;
		     	flag = false;
		     	try {
		       	 Class.forName("com.mysql.cj.jdbc.Driver");  	
		       	 con = DriverManager.getConnection("jdbc:mysql:///hfri", "db_user", "Student-pass");
		            String sql2 = 
		      "SELECT first_name, last_name FROM hfri.project_per_researcher where title = '"
		            + Data.title[i] + "'";
		   	     if (con != null)
		   	     ps = con.prepareStatement(sql2);

		   	     if (ps != null)
		   	    	 rs = ps.executeQuery();
		   	     if (rs != null) {
		           	 while (rs.next()) {
		   	             flag = true;
		   	          Data.htmlPrint[i] =
		   	        		Data.htmlPrint[i].concat("<li>" + rs.getString("first_name") 
		   	        		+ " " + rs.getString("last_name").toUpperCase() + "</li>");	 
		           	 }
		   	     }
		            if (!flag) {
		                pw.println("<h1>Data Not Found.</h1>");
		             }
		   	    } catch (SQLException se) {
		   	         se.printStackTrace();
		   	         pw.println("Error Occured<br>");
		   	    } catch (Exception e) {
		   	         e.printStackTrace();
		   	         pw.println(i + " Unknown Exception Occured<br>");
		   	    } 
		   		finally {
		   	    
		   	         try {
		   	            if (rs != null)
		   	               rs.close();
		   	         } catch (SQLException se) {
		   	            se.printStackTrace();
		   	         }
		   	         try {
		   	            if (ps != null)
		   	               ps.close();
		   	         } catch (SQLException se) {
		   	            se.printStackTrace();
		   	         }
		   	         try {
		   	            if (con != null)
		   	               con.close();
		   	         } catch (SQLException se) {
		   	            se.printStackTrace();
		   	         }
		          
		         	}
	         }
	         for(i = 0; i < aux; i++ ) {
	        	 pw.println(  "<h3>" + Data.Duration[i] + "   &nbsp   " 
	 	        	+  "   -   " + Data.title[i]
	 	        	+"</h3><details class=\"researchers\"> <h3><summary>Researchers that works on project</sumary></h3>"
         		 	+	"<ul>" + Data.htmlPrint[i] + "</ul></details><br>"
         		 	+  "</ul></details>" );
	         }
	         pw.println("<h3><a href='index.html'>Home</a></h3>");
	         pw.close();
	      }
	  }
	

	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doGet(request, response);
	}
}
