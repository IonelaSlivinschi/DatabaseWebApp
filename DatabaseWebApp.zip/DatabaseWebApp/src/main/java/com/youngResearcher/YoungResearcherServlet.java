package com.youngResearcher;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class YoungResearcherServlet
 */
@WebServlet("/YoungResearcherServlet")
public class YoungResearcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String sql = "select first_name, last_name, date_of_birth, count(*) + 1 - count(distinct researcher_id) AS 'Number of projects'  from reasecher_birth_date  group by researcher_id";
	int number;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public YoungResearcherServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter pw = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean flag = false;
		response.setContentType("text/html");
	    pw = response.getWriter();
	    pw.println("<h3><a href='index.html'>Home</a></h3>");
	    pw.println("<html><head><title>Young Researchers</title></head><body>");
	    pw.println("<h3>Researchers younger then 40 years with more than 5 projects</h3> <br/>");
	    

	    
	    
	    
        

	    try {
	    	 Class.forName("com.mysql.cj.jdbc.Driver");  	
	    	 
	    	 
	         con = DriverManager.getConnection("jdbc:mysql:///hfri", "db_user", "Student-pass");
	         if (con != null)
	            ps = con.prepareStatement(sql);
	         if (ps != null)
	            rs = ps.executeQuery();
	         if (rs != null) {
	        	 while (rs.next()) {
		             flag = true;
		             
		             long millis=System.currentTimeMillis();  
		             java.sql.Date currentdate=new java.sql.Date(millis);
		             java.sql.Date date = rs.getDate("date_of_birth");
		             java.util.Date utilcurrentdate = new java.util.Date(currentdate.getTime());
		             java.util.Date utildate = new java.util.Date(date.getTime());
		             long sum = utilcurrentdate.getTime() - utildate.getTime();
		             long years = (sum/1000) / 31556952;
		             String strNumber =  rs.getString("Number of projects");
		             number = Integer.parseInt(strNumber);
		             
		             if(years < 40 && number > 5)
		             pw.println("<h3>" + rs.getString("first_name")  + "&nbsp" 
		            		 	 + rs.getString("last_name") + "</h3>" + "Date of birth:&nbsp"+  rs.getString("date_of_birth") + 
		            		 	"</br>" + "Number of projects:&nbsp" + rs.getString("Number of projects") + "&nbsp" + "</br>_____________________</br>");
		             }
		        }
	         
	         if (!flag) {
	             pw.println("<h1>Data Not Found.</h1>");
	          }
	    } catch (SQLException se) {
	         se.printStackTrace();
	         pw.println("Error Occured");
	      } catch (Exception e) {
	         e.printStackTrace();
	         pw.println("Unknown Exception Occured");
	      } finally {
	         // close JDBC connection
	         try {
	            if (rs != null)
	               rs.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         try {
	            if (ps != null)
	               ps.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         try {
	            if (con != null)
	               con.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         } 
	     
	         pw.close();
	      }

		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
