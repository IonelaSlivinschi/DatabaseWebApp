package com.researcherNoDel;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class ResearcherViewServlet
 */
@WebServlet("/ResearcherViewServlet")
public class ResearcherNoDelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String sql = "select first_name, last_name, count(*) - count(distinct researcher_id) AS 'Number of projects' from researchers_no_deliverable group by researcher_id";

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResearcherNoDelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean flag = false;
		int number;
		response.setContentType("text/html");
	    pw = response.getWriter();
	    pw.println("<h3><a href='index.html'>Home</a></h3>");
	    pw.println("<html><head><title>Not Deliverable Projects</title></head><body>");
	    pw.println("<h3>All researchers that work on 5 or more projects which do not have any deliverables</h3>");
	    


	    try {
	    	 Class.forName("com.mysql.cj.jdbc.Driver");  	
	    	 
	    	 
	         con = DriverManager.getConnection("jdbc:mysql:///hfri", "db_user", "Student-pass");
	         if (con != null)
	            ps = con.prepareStatement(sql);
	         if (ps != null)
	            rs = ps.executeQuery();
	         if (rs != null) {
	        	 while (rs.next()) {
		             flag = true;
		             String strNumber =  rs.getString("Number of projects");
		             
		             for(int i = 0; i < strNumber.length(); i++)
		             {
		            	  number = Integer.parseInt(strNumber);
		            	  if(number + 1 >= 5)	  
		             pw.println("<b>" +  rs.getString("first_name") + "&nbsp" 
		            		 	 + rs.getString("last_name") + "</b>"+ " - &nbsp" + (number+1) + "&nbspprojects" + "</br>");
		             }
		        }
	         }
	         if (!flag) {
	             pw.println("<h1>Data Not Found.</h1>");
	          }
	    } catch (SQLException se) {
	         se.printStackTrace();
	         pw.println("Error Occured");
	      } catch (Exception e) {
	         e.printStackTrace();
	         pw.println("Unknown Exception Occured");
	      } finally {
	         // close JDBC connection
	         try {
	            if (rs != null)
	               rs.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         try {
	            if (ps != null)
	               ps.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         try {
	            if (con != null)
	               con.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         } 
	         pw.close();
	      }

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
